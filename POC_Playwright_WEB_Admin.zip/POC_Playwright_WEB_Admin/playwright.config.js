const { devices } = require('@playwright/test');

/** @type {import('@playwright/test').PlaywrightTestConfig} */
const config = {
  reporter: [['html', {outputFolder: 'report'}]],
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  timeout: 1 * (60*1000),
  use: {
    baseURL: 'https://adm.dev-3.seedz.ag',
    headless: false,
    trace: 'on-first-retry',
    screenshot: 'on',
    video: 'off',
    isMobile: true
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    /*{
      name: 'Pixel',
      use: { ...devices['Pixel 5']},
    }*/
  ],
};

module.exports = config;