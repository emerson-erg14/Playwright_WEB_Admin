const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { PinPage } = require('../pages/PinPage');
const { HomePage } = require('../pages/HomePage');

let loginPage
let pinPage
let homePage

//Befores and Afters

test.beforeEach(async ({ page }) => {
    await page.goto('/', {waitUntil: 'networkidle'})
})

//Tests

test('Login with sucess', async ({ page }) => {

    //Objects instances
    loginPage = new LoginPage(page)
    pinPage = new PinPage(page)
    homePage = new HomePage(page)

    //Arranje
    const login = 'hudson.silva@base2.com.br'
    const password = '123456'
    const codePin = '4321'
    const textExpected = 'Hudson Henrique da Silva'

    //Acts
    await loginPage.clickAcceptCookies()
    await loginPage.fillEmail(login)
    await loginPage.fillPassword(password)
    await loginPage.clickEnterButton()
    await pinPage.fillCodePin(codePin)
    await pinPage.clickContinueButton()

    //Assert
    expect(await homePage.getFullNameLogged()).toEqual(textExpected)
});