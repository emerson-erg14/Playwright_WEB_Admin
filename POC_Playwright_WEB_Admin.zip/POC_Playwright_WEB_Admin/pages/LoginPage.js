
//Mapping

const elements = {

    // This is the list of the fields on the page.
    fields: {
        emailField: '//input[contains(@placeholder, "email")]',
        passwordField: '//input[@type="password"]'
    },

    // This is the list of the buttons on the page.
    buttons: {
        enterButton: '//div[@class="application--wrap"]//button/div[contains(string(), "Entrar")]',
        lostPasswordButton: '//a[contains(string(), "senha")]',
        acceptCookiesButton: '#onetrust-accept-btn-handler'
    },

    // This is the list of the Links on the page.
    Links: {},

    // This is the list of the labels on the page.
    labels: {},

    // This is the list of the messages on the page.
    messages: {}
}


//Actions

class LoginPage {

    constructor(page) {
        this.page = page
    }
    
    async fillEmail(email) {
        await this.page.waitForSelector(elements.fields.emailField)
        await this.page.fill(elements.fields.emailField, email)
    }

    async fillPassword(password) {
        await this.page.waitForSelector(elements.fields.passwordField)
        await this.page.fill(elements.fields.passwordField, password)
    }

    async clickEnterButton() {
        await this.page.click(elements.buttons.enterButton)
    }

    async clickAcceptCookies() {
        await this.page.waitForSelector(elements.buttons.acceptCookiesButton)
        await this.page.click(elements.buttons.acceptCookiesButton)
    }

}

module.exports = { LoginPage }