
//Mapping

const elements = {

    // This is the list of the fields on the page.
    fields: {
        pinCodeField: '//input[contains(@placeholder, "pincode")]'
    },

    // This is the list of the buttons on the page.
    buttons: {
        continueButton: '//button/div[contains(string(), "Continuar")]',
        lostPasswordButton: '//a[contains(string(), "senha")]'
    },

    // This is the list of the Links on the page.
    links: {},

    // This is the list of the labels on the page.
    labels: {},

    // This is the list of the messages on the page.
    messages: {}
}


//Actions

class PinPage {

    constructor(page) {
        this.page = page
    }

    async fillCodePin(codePin) {
        await this.page.waitForSelector(elements.fields.pinCodeField)
        await this.page.fill(elements.fields.pinCodeField, codePin)
    }

    async clickContinueButton() {
        await this.page.click(elements.buttons.continueButton)
    }

}


module.exports = { PinPage }