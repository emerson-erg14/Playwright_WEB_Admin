
//Mapping

const elements = {

    // This is the list of the fields on the page.
    fields: {},

    // This is the list of the buttons on the page.
    buttons: {
        userMenuButton: '#btn-app-menu-users'
    },

    // This is the list of the Links on the page.
    Links: {},

    // This is the list of the labels on the page.
    labels: {
        fullNameLogged: '//span[@class=\"user\"]//child::strong'
    },

    // This is the list of the messages on the page.
    messages: {}
}


//Actions

class HomePage{

    constructor(page) {
        this.page = page
    }

    async navigateToUserMenu() {
        await this.page.waitForSelector(elements.buttons.userMenuButton)
        await this.page.click(elements.buttons.userMenuButton)
    }

    async getFullNameLogged() {
        await this.page.waitForSelector(elements.labels.fullNameLogged)
        return await this.page.innerText(elements.labels.fullNameLogged)
    }

}


module.exports = { HomePage }